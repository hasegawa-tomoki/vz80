nextor-vz80 1.0.0 — vz80 用 Nextor カーネル ROM

nextor-vz80.rom は Nextor 2.1.2（https://github.com/Konamiman/Nextor）のカーネルに、vz80 の仮想ドライブ
（仮想フロッピー / 仮想ハードディスク）用のデバイスドライバを組み込んだ 128 KB（ASCII 16K マッパ）の ROM です。

使い方: この ROM を microSD カードに置き、vz80 の Web UI「SD カード」で ROM 名をクリックしてスロット（例: 0-1）に
マウントします。MSX が再起動すると Nextor が立ち上がり、「ドライブ設定」の行（仮想 FDD / 仮想 HDD）がドライブになります。

ライセンス
- Nextor カーネル部分: LICENSE-NEXTOR.md（MSX-DOS (c) The MSX Licensing Corporation、Nextor (c) Nestor Soriano Vilchez）。
  商用利用（この ROM を売ること）は権利者の許可なしにはできません。この ROM は無償で配布しています。
- vz80 ドライバ部分（ソースはリポジトリの tools/nextor/vz80drv.mac）: LICENSE-VZ80.txt（MIT）。
